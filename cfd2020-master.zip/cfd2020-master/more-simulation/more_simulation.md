# More on simulation

Probability can be confusing, even for experienced mathematicians.

In this section, we use more simulation to solve probability problems.  In the
process, we learn more about arrays.

When you have read this chapter, try the [simulation exercises](../exercises/simulation).
