# Licenses for data not otherwise specified

* `gender_data.csv` - see
  <https://github.com/matthew-brett/datasets/tree/master/gender_stats>.
   CC-BY, attribution to the World Bank.

* `mosquito_beer.csv` - see
  <https://github.com/matthew-brett/datasets/tree/master/mosquito_beer>.
   CC-BY, attribution to Dr Thierry Lefèvre - see link above for detail.

* `rate_my_course.csv` - see
  <https://github.com/matthew-brett/datasets/tree/master/good_and_easy>.
   The license is not clear - see link for details.  For now, assume CC-0.
