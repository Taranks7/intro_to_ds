---
layout: single
title: Setting up software and exercises
permalink: /setup
---

# Setting up software and exercises

* [Installing the base software on your computer](installing).
* [Starting a terminal application on your computer](start_terminal).
* [Installing extra packages](installing_packages) such as OKpy.
* [Extracting zip arcives](extracting) such as OKpy exercise `.zip` files.
