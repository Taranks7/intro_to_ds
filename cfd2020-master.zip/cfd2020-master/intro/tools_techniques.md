# Tools and techniques

As [you remember](what-is-data-science):

> Data science is an approach to data analysis with a foundation in code
> and algorithms.

The data scientist uses [computational tools](computational-tools) in order to
apply [statistical techniques](statistical-techniques).
