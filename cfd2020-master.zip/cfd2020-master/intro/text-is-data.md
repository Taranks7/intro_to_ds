# Text is data

Everything that you can store on the computer, or see on the web, is data.

When you can use code, you can analyze all these kinds of data.

In the next few sections, we will download and analyze the text of *Pride and
Prejudice* by Jane Austen.
