# Populations and permutations

In this chapter, we discover that permutation allows us to simulate data in
many more situations than we have seen thus far.

We build up the tools to use permutation for a test of differences between two
groups.
