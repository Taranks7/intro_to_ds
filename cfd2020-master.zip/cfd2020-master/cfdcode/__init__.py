""" Support code for textbook
"""

from . import ucb_page

def setup(app):
    ucb_page.setup(app)
