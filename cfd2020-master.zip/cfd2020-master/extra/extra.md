This section has some extra notes that are not part of the main course.  You do
not need to know the material in this section, but you might find it
interesting, or useful for your reference.
