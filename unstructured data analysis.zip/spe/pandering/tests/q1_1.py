test = {
  'name': 'Question 1_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> unemployment.iloc[0, :3]
          Date        1994-01-01
          NEI            10.0974
          NEI-PTER        11.172
          Name: 0, dtype: object
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
